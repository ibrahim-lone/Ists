#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "metis.h"

#define MAX_EDGES 100000000

typedef struct {
    idx_t u, v;
} Edge;

int compare(const void *a, const void *b) {
    idx_t x = *(idx_t *)a;
    idx_t y = *(idx_t *)b;
    return x - y;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <edge_list_file>\n", argv[0]);
        return 1;
    }

    FILE *f = fopen(argv[1], "r");
    if (!f) {
        perror("Error opening file");
        return 1;
    }

    Edge *edges = malloc(MAX_EDGES * sizeof(Edge));
    idx_t max_node = 0;
    idx_t edge_count = 0;
    idx_t u, v;

    // Skip comments
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        if (line[0] == '#') continue;
        if (sscanf(line, "%d %d", &u, &v) == 2) {
            edges[edge_count++] = (Edge){u - 1, v - 1}; // Convert to 0-based
            edges[edge_count++] = (Edge){v - 1, u - 1}; // Undirected edge
            if (u > max_node) max_node = u;
            if (v > max_node) max_node = v;
        }
    }
    fclose(f);

    idx_t nvtxs = max_node;
    idx_t *xadj = calloc(nvtxs + 1, sizeof(idx_t));
    idx_t *degree = calloc(nvtxs, sizeof(idx_t));

    // Count degree
    for (idx_t i = 0; i < edge_count; i++) {
        degree[edges[i].u]++;
    }

    // Build xadj
    xadj[0] = 0;
    for (idx_t i = 0; i < nvtxs; i++) {
        xadj[i + 1] = xadj[i] + degree[i];
        degree[i] = 0; // reuse as index tracker
    }

    idx_t *adjncy = malloc(edge_count * sizeof(idx_t));
    for (idx_t i = 0; i < edge_count; i++) {
        idx_t from = edges[i].u;
        idx_t to = edges[i].v;
        adjncy[xadj[from] + degree[from]++] = to;
    }

    // Optional: sort neighbors (not required by METIS, but nice for consistency)
    for (idx_t i = 0; i < nvtxs; i++) {
        qsort(adjncy + xadj[i], xadj[i + 1] - xadj[i], sizeof(idx_t), compare);
    }

    idx_t ncon = 1;
    idx_t nparts = 3;
    idx_t *part = malloc(nvtxs * sizeof(idx_t));
    idx_t objval;

    int status = METIS_PartGraphKway(&nvtxs, &ncon, xadj, adjncy,
                                     NULL, NULL, NULL, &nparts,
                                     NULL, NULL, NULL,
                                     &objval, part);

    if (status == METIS_OK) {
        printf("Partitioning successful. Edge cuts: %d\n", objval);
        for (idx_t i = 0; i < nvtxs; i++) {
            printf("Vertex %d -> Part %d\n", i + 1, part[i]);
        }
    } else {
        printf("METIS partitioning failed.\n");
    }

    free(xadj);
    free(adjncy);
    free(part);
    free(edges);
    free(degree);

    return 0;
}

